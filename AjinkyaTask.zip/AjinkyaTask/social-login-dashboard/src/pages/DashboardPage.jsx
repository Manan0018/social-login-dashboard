import React from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const DashboardPage = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();


  const handleLogout = () => {
    logout(); 
    navigate("/"); 
  };

  if (!user) {
    return (
      <div className="d-flex justify-content-center align-items-center vh-100 bg-light">
        <div className="text-center text-muted">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-2">
            Loading user data or unauthorized access. Redirecting...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-5">
      <div
        className="card shadow-sm p-4 text-center mx-auto"
        style={{ maxWidth: "600px" }}
      >
        <h2 className="card-title h2 mb-4">Welcome, {user.name}!</h2>

        {user.picture && (
          <img
            src={user.picture}
            alt={user.name}
            className="rounded-circle mx-auto mb-4 border border-primary"
            style={{ width: "120px", height: "120px", objectFit: "cover" }}
          />
        )}

        <div className="text-start mb-4">
          <p className="lead">Here's your basic information:</p>
          <ul className="list-group list-group-flush">
            <li className="list-group-item d-flex justify-content-between align-items-center">
              <strong>Name:</strong>
              <span>{user.name}</span>
            </li>
            <li className="list-group-item d-flex justify-content-between align-items-center">
              <strong>Email:</strong>
              <span>{user.email}</span>
            </li>
            <li className="list-group-item d-flex justify-content-between align-items-center">
              <strong>Logged in via:</strong>
              <span>{user.provider}</span>
            </li>
          </ul>
        </div>

        {/* Navigation buttons */}
        <div className="d-grid gap-2">
          <button
            onClick={() => navigate("/profile")}
            className="btn btn-primary"
          >
            View Profile
          </button>
          <button onClick={() => navigate("/users")} className="btn btn-info">
            View Users (API Demo)
          </button>
          <button
            onClick={() => navigate("/settings")}
            className="btn btn-secondary"
          >
            Settings (Form Demo)
          </button>
          <button onClick={handleLogout} className="btn btn-danger mt-3">
            Logout
          </button>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
