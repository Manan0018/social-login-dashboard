import React from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const ProfilePage = () => {
  const navigate = useNavigate();
  const { user } = useAuth(); 
  const profileData = user || {
    name: "John Doe (Mock Data)",
    email: "john.doe@example.com",
    picture: "https://via.placeholder.com/150/CCCCCC/000000?text=Profile",
    provider: "Mock Data",
    posts: 125,
    likes: 2500,
    followers: 1500,
  };

  return (
    <div className="container py-5">
      <div className="card shadow-sm p-4 mx-auto" style={{ maxWidth: "600px" }}>
        <div className="card-body text-center">
          <h2 className="card-title h3 mb-4">User Profile</h2>

          <img
            src={profileData.picture}
            alt={profileData.name}
            className="rounded-circle mx-auto mb-4 border border-primary"
            style={{ width: "150px", height: "150px", objectFit: "cover" }}
          />

          <h5 className="card-subtitle mb-2 text-muted">{profileData.name}</h5>
          <p className="card-text mb-4">{profileData.email}</p>

          <ul className="list-group list-group-flush mb-4">
            <li className="list-group-item d-flex justify-content-between align-items-center">
              <strong>Provider:</strong>
              <span>{profileData.provider}</span>
            </li>
            <li className="list-group-item d-flex justify-content-between align-items-center">
              <strong>Posts:</strong>
              <span className="badge bg-primary rounded-pill">
                {profileData.posts || "N/A"}
              </span>
            </li>
            <li className="list-group-item d-flex justify-content-between align-items-center">
              <strong>Likes:</strong>
              <span className="badge bg-success rounded-pill">
                {profileData.likes || "N/A"}
              </span>
            </li>
            <li className="list-group-item d-flex justify-content-between align-items-center">
              <strong>Followers:</strong>
              <span className="badge bg-info rounded-pill">
                {profileData.followers || "N/A"}
              </span>
            </li>
          </ul>

          <button
            onClick={() => navigate("/dashboard")}
            className="btn btn-outline-secondary"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
