import React from "react";
import { useGoogleLogin } from "@react-oauth/google";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import linkedinIcon from "../assets/linkedin_icon.png"; 
import googleIcon from "../assets/google_icon.png";

const LoginPage = () => {
  const navigate = useNavigate();
  const { login } = useAuth();


  const handleGoogleSuccess = async (tokenResponse) => {
    try {
      // Fetch user info from Google's API
      const res = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
        headers: {
          Authorization: `Bearer ${tokenResponse.access_token}`,
        },
      });

      const userInfo = await res.json();
      const userData = {
        name: userInfo.name,
        email: userInfo.email,
        picture: userInfo.picture,
        provider: "Google",
      };

      login(userData); 
      navigate("/dashboard");
    } catch (error) {
      console.error("Failed to fetch user info:", error);
      alert("Google login failed. Please try again.");
    }
  };

  const handleGoogleFailure = (error) => {
    console.error("Google login failed:", error);
    alert("Google login failed. Please try again.");
  };

  const googleLogin = useGoogleLogin({
    onSuccess: handleGoogleSuccess,
    onError: handleGoogleFailure,
    flow: "implicit", 
  });

  // LinkedIn Login (Requires backend for full OAuth flow)
  const handleLinkedInLogin = () => {
    alert(
      "LinkedIn login is more complex and typically requires a backend to exchange the authorization code for an access token. For this demo, we will simulate a successful login."
    );
    
    const dummyLinkedInUser = {
      name: "Manan LinkedIn User",
      email: "manan.linkedin@example.com",
      picture: "https://via.placeholder.com/150/0000FF/FFFFFF?text=LI", 
      provider: "LinkedIn",
    };
    login(dummyLinkedInUser); 
    navigate("/dashboard"); 
  };

  return (
    <div className="d-flex justify-content-center align-items-center vh-100 bg-light">
      <div
        className="card shadow-sm p-4"
        style={{ maxWidth: "400px", width: "100%" }}
      >
        <div className="card-body text-center">
          <h2 className="card-title h3 mb-4">Login</h2>
          <div className="d-grid gap-3">
            <button
              onClick={() => googleLogin()}
              className="btn btn-outline-primary d-flex align-items-center justify-content-center py-2"
            >
              <img
                src={googleIcon}
                alt="Google"
                className="me-2"
                style={{ height: "20px" }}
              />
              Sign in with Google
            </button>
            <button
              onClick={handleLinkedInLogin}
              className="btn btn-outline-info d-flex align-items-center justify-content-center py-2"
            >
              <img
                src={linkedinIcon}
                alt="LinkedIn"
                className="me-2"
                style={{ height: "20px" }}
              />
              Sign in with LinkedIn
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
